# Content:
    - data.m
    - cubicspline.m
    - explanations.pdf

# Instructions:
    To run this code, first in data.m type the X, Y and/or Z values of the points you want to plot. Then set the dimension variable to select if you want to draw in 2D or in 3D. And laslty select the number of nodes that will the plot be done with. After this configuration, you will have to just run cubicspline.m and the plot will appear with your selected configuration.

# Authors:
    Jon Galaz (jon.galaz@digipen.edu) & Pablo Riesco (p.riesco@digipen.edu)